import { useEffect, useMemo, useState } from "react";
import { Map as KakaoMap, MapMarker } from "react-kakao-maps-sdk";
// import { LatLng } from "../../types/map";
import { debounce } from "lodash";
// import { ReactComponent as IconRefresh } from "../../assets/icons/refresh.svg";
// import { ReactComponent as IconMyLocation } from "../../assets/icons/my-location.svg";
import locationIcon from "/location.png"; // 현재 위치 아이콘

function MapView() {
  // 지도의 중심좌표
  const [center, setCenter] = useState({
    lat: 33.450701,
    lng: 126.570667,
  });

  // 현재 위치
  const [position, setPosition] = useState({
    lat: 33.450701,
    lng: 126.570667,
  });

  // 현재 위치로 중심좌표 재설정
  const setCenterToMyPosition = () => {
    setCenter(position);
  };

  // 지도 이동 시 중심좌표 업데이트 (디바운스)
  const updateCenterWhenMapMoved = useMemo(
    () =>
      debounce((map) => {
        const latlng = map.getCenter();
        console.log("지도 이동 → 중심좌표:", latlng);
        setCenter({
          lat: latlng.getLat(),
          lng: latlng.getLng(),
        });
      }, 500),
    []
  );

  // 컴포넌트 초기화 시 위치 정보 설정
  useEffect(() => {
    // 최초 중심좌표 = 현재 위치
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      setCenter({ lat: latitude, lng: longitude });
    });

    // 현재 위치 지속 감지
    navigator.geolocation.watchPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      setPosition({ lat: latitude, lng: longitude });
    });
  }, []);

  return (
    <div className="relative w-full h-full">
      <KakaoMap
        className="w-full h-full"
        center={center}
        level={4}
        onCenterChanged={updateCenterWhenMapMoved}
      >
        {/* 현재 위치 마커 */}
        <MapMarker
          position={position}
          image={{
            src: locationIcon,
            size: { width: 30, height: 30 },
          }}
        />
      </KakaoMap>

      {/* 내 위치로 이동 버튼 */}
      {/* <button
        className="absolute bottom-4 right-4 bg-white shadow p-2 rounded-full"
        onClick={setCenterToMyPosition}
      >
        <IconMyLocation width={24} height={24} />
      </button> */}

      {/* 새로고침 버튼 (필요 시 기능 추가 가능) */}
      {/* <button
        className="absolute bottom-4 right-16 bg-white shadow p-2 rounded-full"
        onClick={() => window.location.reload()}
      >
        <IconRefresh width={24} height={24} />
      </button> */}
    </div>
  );
}

export default MapView;




// function MapView({ location, stations }) {
//   useEffect(() => {
//     if (!window.kakao || !location) return;

//     const map = new window.kakao.maps.Map(document.getElementById("map"), {
//       center: new window.kakao.maps.LatLng(location.lat, location.lng),
//       level: 4,
//     });

//     // 내 위치 마커
//     new window.kakao.maps.Marker({
//       position: new window.kakao.maps.LatLng(location.lat, location.lng),
//       map,
//       title: "내 위치",
//     });

//     // 주변 정류장 마커
//     stations.forEach((s) => {
//       const marker = new window.kakao.maps.Marker({
//         position: new window.kakao.maps.LatLng(s.gpslati, s.gpslong),
//         map,
//         title: s.nodeNm,
//       });

//       window.kakao.maps.event.addListener(marker, "click", () => {
//         alert(`정류장: ${s.nodeNm}`);
//       });
//     });
//   }, [location, stations]);

//   return <div id="map" style={{ width: "100%", height: "500px" }} />;
// }
