import React from 'react';
import {Input, Space} from "antd";

function BusRoute(props) {
    return (
        <div>


        </div>
    );
}

export default BusRoute;