import React from 'react';

function My(props) {
    return (
        <div></div>
    );
}

export default My;